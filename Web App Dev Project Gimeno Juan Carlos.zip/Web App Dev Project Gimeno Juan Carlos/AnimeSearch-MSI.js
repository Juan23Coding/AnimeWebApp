const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '373bfbe667msh79c1a9153e16a71p195495jsn0fa0a7577411',
		'X-RapidAPI-Host': 'anime-db.p.rapidapi.com'
	}
};

const searchInput= document.querySelector('input');
const btn= document.querySelector('button');
const img= document.getElementById('img');

let params=""
const callParams = () =>{
    params= searchInput.value
    fetch(`https://anime-db.p.rapidapi.com/anime?page=1&size=10&search=${params}`, options)
	.then(response => response.json())
	.then(content => {
        let output= '';
        content.data.map(item => {
            output += `
            <p>ID: ${item._id}</p>
            <p>Title: ${item.title}</p>
            <p><img src="${item.image}" style="max-width=100%, max-height=100%"/>Synopsis: ${item.synopsis}</p>
            <p>Alternative Title: ${item.alternativeTitles[0]}</p> <br>`;
            console.log(item.title)
          
        })
        document.querySelector('div').innerHTML= output;

        
        
    })
	.catch(err => console.error(err));
    searchInput.value=''
    
}
btn.addEventListener('click', callParams);

$(document).ready(function() {
    $('#fadeBtn').click(function() {
        $('p').fadeToggle(1000);
    })
});