//Author: Juan Carlos Gimeno
const options = {
  method: 'GET',
  headers: {
    'X-RapidAPI-Key': '373bfbe667msh79c1a9153e16a71p195495jsn0fa0a7577411',
    'X-RapidAPI-Host': 'youtube-search-results.p.rapidapi.com'
  }
};

const searchInput = document.querySelector('input');
const btn = document.querySelector('button');
const img = document.getElementById('img');


/* 08/12/2022
@Reference https://www.youtube.com/watch?v=QegE9i4UW4I&list=LL&index=5
@Author CodeItRaw
*/
let params = ""
const callParams = () => {
  params = searchInput.value
  fetch(`https://youtube-search-results.p.rapidapi.com/youtube-search/?q=${params}`, options)
    .then(response => response.json())
    .then(result => {
      let output = '';
      let videoLink = '';
      let vidId = '';
      result.items.slice(0, 5).map(item => {

        output += `<div id="loop">
            <img src="https://i.ytimg.com/vi/${item.id}/hq720.jpg" width="400"/>
            </div>
            <p>Type: ${item.type}</p>
            <p>Title: ${item.title}</p>
            <p id="ID">ID: ${item.id}</p>
            <p>Author: ${item.author.name}</p>
            <p>Views: ${item.views}</p>
            <button onclick="playButton()">Play Video</button><br> `;

        vidId += `${item.id}`;
        console.log(output);
      });

      document.querySelector('.main').innerHTML = output;
    })
    .catch(err => console.error(err));
}
btn.addEventListener('click', callParams);


/* 08/12/2022
@Reference https://stackoverflow.com/questions/15090782/youtube-autoplay-not-working-on-mobile-devices-with-embedded-html5-player
@Author brenjit, Zubi
*/

//This loads the iframe API code while the rest of the functions are called
var tag = document.createElement('script');
tag.setAttribute('sandbox', 'allow-presentation');

tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// This function creates an an iframe tag as well as the youtube
// video player when the iframe_api has loaded

function onYouTubeIframeAPIReady() {
  console.log('Player Ready');
}

//This function is called by the API when the player is ready
//then autoplays the video
function onPlayerReady(event) {
  event.target.playVideo();
}

// These functions handle the state changes of the video
// such as playing state, paused/stopped state, length of runtime,
// The setTimeout parameter is set to 0 so that the video is
//played to its full length
var done = false;
function onPlayerStateChange(event) {
  if (event.data == YT.PlayerState.PLAYING && !done) {
    setTimeout(0);
    done = true;
  }
}

function stopVideo() {
  player.stopVideo();
}

var player;
//This function plays the video
function playThisVideo(vidId) {
  //this deletes the previous player so that a new video can be played
  //without having to refresh
  if (player) {
    player.destroy();
  }
  //This is the declaration of anew instance of a youtube player
  //in the player variable and displays it at the element
  //where 'player' is the ID in Youtube.html
  player = new YT.Player('player', {
    height: '390',
    width: '640',
    videoId: vidId,
    events: {
      'onReady': onPlayerReady,
      'onStateChange': onPlayerStateChange
    }
  });
  player.h.attributes.sandbox.value = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-presentation";
}

//This function is called when the onClick() event for the play
//button is triggered
function playSearch() {
  //vidSearch variable stores user input in html input
  //element where the ID is 'vidSearch'
  var vidSearch = document.getElementById('vidSearch').value;
  playThisVideo(vidSearch); //vidSearch(user input/video ID) is passed to the playThisVideo() function

}

function playButton() {
  var videoPlay = document.querySelector('#ID').textContent;
  //playThisVideo(videoPlay);
  alert(videoPlay);
}

//animation for content
$(document).ready(function () {
  $('#fadeBtn').click(function () {
    $('p').fadeToggle(1000);
  });

});