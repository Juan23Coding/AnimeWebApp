//Author: Carolina Torres
function SearchBtn() {
    //alert("he clickado")

    let textVal = document.getElementById('text-value')

    if (textVal.value.length <= 0) {
        alert("Insert title")
        return
    } else {
        AnimeAPI(textVal.value)
        //console.log(textVal.value)
    }
    textVal.value = ''

}
function AnimeAPI(title) {

    let container = document.getElementById('container')
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '313b35dc99msh6aa605fb08e7b3ep1c4dabjsnffdad87a49e7',
            'X-RapidAPI-Host': 'anime-quotes1.p.rapidapi.com'
        }
    };
    const app = document.querySelector('#container');
    let text = title
    let url = `https://anime-quotes1.p.rapidapi.com/api/quotes/anime?title=${text}`
    fetch(url, options)
        .then((res) => res.json())
        .then(data => {
            data.forEach(title => {
                console.log(title.anime)
                console.log(title.character)
                console.log(title.quote)
                const p =document.createElement('p')
                p.innerHTML = `<section>
                <h3>${title.anime}</h3>
                <li>Character: ${title.character}</li>
                <li>Quote: ${title.quote}</li>
                </section`;
                
                app.appendChild(p)
                
            })
            
        })

}
function FadeSearch() {
    location.reload();
}
function RandomeQuote(){
    let container = document.getElementById('container')
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '313b35dc99msh6aa605fb08e7b3ep1c4dabjsnffdad87a49e7',
            'X-RapidAPI-Host': 'anime-quotes1.p.rapidapi.com'
        }
    };
    const app = document.querySelector('#container');
    let url = `https://anime-quotes1.p.rapidapi.com/api/quotes`
    fetch(url, options)
        .then((res) => res.json())
        .then(data => {
            data.forEach(title => {
                console.log(title.anime)
                console.log(title.character)
                console.log(title.quote)
                const p =document.createElement('p')
                p.innerHTML = `<section>
                <h3>${title.anime}</h3>
                <li>Character: ${title.character}</li>
                <li>Quote: ${title.quote}</li>
                </section`;
                
                app.appendChild(p)
                
            })
            
        })

}