//Author: Solomon Salifu
const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '373bfbe667msh79c1a9153e16a71p195495jsn0fa0a7577411',
		'X-RapidAPI-Host': 'anime-hub.p.rapidapi.com'
	}
};

fetch('https://anime-hub.p.rapidapi.com/getnews?nNews=120', options)
	.then(response => response.json())
	.then(data => {
		let output= '';
		data.forEach(title => {
			output += `<div>
			<p>Title: ${title.title}</p>
			<a href="${title.link}" Link </a>
			<p><img src="${title.image}"/></p>
			<p>Text: ${title.text}</p>
			<p>Code: ${title.newsNumber}</p></div> <br>`;
			console.log(output);
		})
		document.querySelector('.main').innerHTML= output;
	})
	.catch(err => console.error(err));